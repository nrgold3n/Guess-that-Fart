import { FartSound, FartID } from "./types";

// Placeholder fart sounds
export const fartSounds: FartID[] = ["grandma", "elephant", "machine", "alien"];

export function playFartSound(id: FartID): void {
  console.log("Playing fart sound:", id);
  // Placeholder audio functionality
}
