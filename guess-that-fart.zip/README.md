# Guess That Fart (MVP)

## Placeholder Audio Structure
This project uses temporary fart IDs, labels, and file paths. They will be replaced with real audio later.

## Current Features
- Start game
- Play placeholder fart sounds
- Score system (+1 for correct guesses)
- Dynamic guess buttons

